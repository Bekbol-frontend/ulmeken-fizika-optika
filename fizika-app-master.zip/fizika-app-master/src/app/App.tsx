import { AppRoutes } from "./provider/AppRouter";

function App() {
  return <AppRoutes />;
}

export default App;
