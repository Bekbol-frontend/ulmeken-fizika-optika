export { default as AppConfig } from "./ui/AppConfig";
