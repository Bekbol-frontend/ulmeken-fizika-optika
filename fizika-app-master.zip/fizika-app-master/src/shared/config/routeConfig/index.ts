export const appRoutes = {
  home: "/",
} as const;
